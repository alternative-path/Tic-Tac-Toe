import csv
import json
import pandas as pd
from tld import get_tld

class File_Processing:

    def fame_clean(self,path,clearcsv):
        try:
          df=pd.read_csv(path, encoding= 'unicode_escape')
        except:
          print("File not Found or File Error")  
        rows = len(df.axes[0])  # computing number of rows and columns
        #cols = len(df.axes[1])
        new_field=[]
        for x in range(0,rows):
            try:
                if type(df.loc[x,'Website'])==type("str"): 
                    url=df.loc[x,'Website']
                    df.loc[x,'Website']=df.loc[x,'Website'].upper()
                    if url[0:4]!="http":
                       url="http://"+url                
                    url=get_tld(url,as_object=True)
                    sd=url.subdomain
                    domain=url.fld
                    if sd[0:3]=="www" or sd[0:3]=="WWW":
                        
                        if len(sd)>3:
                          sd=sd[4:]+"."
                        else:
                          sd=""    
                            
                    new_field.append(sd+domain)
                else:
                    df.loc[x,'Website']="Unknown"
                    new_field.append("Unknown")    
                            
            except:
                print("url name error")
                new_field.append("Unknown")    
                            
            print(x)
        
        try:    
          df.insert(4,'Url',new_field) 
          df.sort_values(["Number of employees"], 
                    axis=0,
                    ascending=[False], 
                    inplace=True)

          df=df[["Company name","Registered number","Number of employees",
                 "Website","Url","BvD ID number","BvD sector","R/O City","R/O Country" ]]         
          df.to_csv(clearcsv,index=False,na_rep='Unknown')
        except:
            print("Error in write Clean Csv file")
        print("cleaning done")


    def fame_csvto_json(self,csvFilePath, jsonFilePath):
       
        data = []
     
        # Open a csv reader called DictReader
        with open(csvFilePath, encoding='utf-8') as csvf:
            csvReader = csv.DictReader(csvf)
        
         
            # Convert each row into a dictionary
            # and add it to data
            for rows in csvReader:
                array_sector=[]
                rows['Number of employees']=int(rows['Number of employees'])
                array_sector=rows['BvD sector'].split(",")
                rows['BvD sector']=array_sector
                #print(csvReader)     
                # Assuming a column named 'No' to
                # be the primary key
            
                data.append(rows)
 
        # Open a json writer, and use the json.dumps()
        # function to dump data
        try:

          with open(jsonFilePath, 'w', encoding='utf-8') as jsonf:
             jsonf.write(json.dumps(data, indent=4))
        except:
             print("Error in write Clean json file")



    def dynamo_clean(self,path,clearcsv):
        try:
          df=pd.read_csv(path, encoding= 'unicode_escape')
        except:
          print("File not Found or File Error")  
        rows = len(df.axes[0])  # computing number of rows and columns
        #cols = len(df.axes[1])
        new_field=[]
        for x in range(0,rows):
            try:
            
                if type(df.loc[x,'Website'])==type('str'):
                    url=df.loc[x,'Website']
                    df.loc[x,'Website']=df.loc[x,'Website'].upper()
                    if url[0:4]!="http":
                       url="http://"+url                
                    url=get_tld(url,as_object=True)
                    sd=url.subdomain
                    domain=url.fld
                    if sd[0:3]=="www" or sd[0:3]=="WWW":
                        
                        if len(sd)>3:
                          sd=sd[4:]+"."
                        else:
                          sd=""    
                            
                    new_field.append(sd+domain)
                else:
                    print("warning! url unknown")
                    df.loc[x,'Website']="Unknown"
                    new_field.append("Unknown")    
                            
            except:
                print("url name error")
                new_field.append("Unknown")    
                            
            print(x)
        
        try:    
          df.insert(4,'Url',new_field) 
          
          df=df[["Name (ID)","Deal status","LinkedIn URL",
                 "Website","Url","Date created","Company Reg","Internal ID" ]]         
          df.to_csv(clearcsv,index=False,na_rep='Unknown')
        except:
            print("Error in write Clean Csv file")
        print("Dynamo cleaning done")

 

    def dynamo_csvto_json(self,csvFilePath, jsonFilePath):
       
        data = []
     
        # Open a csv reader called DictReader
        with open(csvFilePath, encoding='utf-8') as csvf:
            csvReader = csv.DictReader(csvf)
        
         
            # Convert each row into a dictionary
            # and add it to data
            for rows in csvReader:
                data.append(rows)
 
        # Open a json writer, and use the json.dumps()
        # function to dump data
        try:

          with open(jsonFilePath, 'w', encoding='utf-8') as jsonf:
             jsonf.write(json.dumps(data, indent=4))
             print("Dynamo Json Created Succesfully")
        except:
             print("Error in write Clean json file")
        
        
from filehandling import File_Processing
from mongo_insert import fame,dynamo
from scrap_clean_combine import scrap

fame_file_csv= r"C:\Users\Anil\Downloads\qpefiles\fame\fame.csv"
fame_file_json=r"C:\Users\Anil\Downloads\qpefiles\fame\fame.json"
fame_cleanfile_csv=r"C:\Users\Anil\Downloads\qpefiles\fame\fame_clean.csv"

dynamo_file_csv= r"C:\Users\Anil\Downloads\qpefiles\Dynamo\dynamo.csv"
dynamo_file_json=r"C:\Users\Anil\Downloads\qpefiles\Dynamo\dynamo.json"
dynamo_cleanfile_csv=r"C:\Users\Anil\Downloads\qpefiles\Dynamo\dynamo_clean.csv"

dump_path=r"C:\Users\Anil\Downloads\qpefiles\scrapy\mongodump.json"
scrap_path=r"C:\Users\Anil\Downloads\qpefiles\scrapy\scrapy4.json"
scrap_combine=r"C:\Users\Anil\Downloads\qpefiles\scrapy\scrap_combine.csv"


#x=File_Processing()
#x.fame_clean(fame_file_csv,fame_cleanfile_csv)
#x.fame_csvto_json(fame_cleanfile_csv,fame_file_json)
#x.dynamo_clean(dynamo_file_csv,dynamo_cleanfile_csv)
#x.dynamo_csvto_json(dynamo_cleanfile_csv,dynamo_file_json)

y=fame()
#y.fame_insert(fame_file_json)


y=dynamo()
#y.dynamo_insert(dynamo_file_json)



k=scrap()
k.scrap_comnbine(dump_path,scrap_path,scrap_combine)
#k.scrap_insert(scrap_combine)
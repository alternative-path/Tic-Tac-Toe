from ast import Mult
from typing import OrderedDict
import pymongo
import json
from pymongo import MongoClient, InsertOne

class fame:
      def fame_insert(self,path): 
        
        try:    
            client=pymongo.MongoClient("mongodb+srv://user:user@cluster0.l9qmd.mongodb.net/qpe?retryWrites=true&w=majority")
        except:
            print("error ocurr in connecting Atlas") 
            return 0
        try:
            db=client['qpe']
        except:
            print("error occur in fetching database")
            return 0 
        try:
         
            if "fame" in db.list_collection_names():
                 collection=db['fame']
            else:
                    db.create_collection('fame', validator={
                        '$jsonSchema': {
                            'bsonType': 'object',
                            'additionalProperties': True,
                            'required': ['Company name','Registered number','Number of employees',
                                        'Website','Url','BvD ID number','BvD sector','R/O City','R/O Country'],
                        'properties': {
                                'Company name': {
                                    'bsonType': 'string',
                                    'description': 'Set to default value',

                                },
                                'Registered number': {
                                    'bsonType': 'string',
                                    'description': 'Set to default value',
                                },
                                'Number of employees': {
                                    'bsonType': 'int',
                                  
                                },
                                'Website': {
                                    'bsonType': 'string',
                                    'description': 'Set to default value',
                                },
                                'Url': {
                                    'bsonType': 'string',
                                    'description': 'Set to default value',
                                },
                                'BvD ID number': {
                                    'bsonType': 'string',
                                  'description': 'Set to default value',  
                                },
                                'BvD sector': {
                                    'bsonType': 'array',
                                    'description': 'Set to default value',
                                },
                                'R/O City': {
                                    'bsonType': 'string',
                                    'description': 'Set to default value',
                                },
                                'R/O Country': {
                                    'bsonType': 'string',
                                    'description': 'Set to default value',
                                },
                                

                        }
                        }
                        })
                    db['fame'].create_index(
                       [("Url", pymongo.ASCENDING)],
                         unique=True
                        )   
                    
                            
                    collection=db['fame']    

        except:
            print("error occur in fetching collection")
            return 0
        requesting = []
        try:
         with open(path,encoding='utf-8') as f:
                myDict = json.load(f)
                #print(myDict)
                #requesting.append(InsertOne(myDict))
        except:
         print("json file error") 
         return 0
        try:        
          result = collection.insert_many(myDict,ordered=False)
          print("Insertion Completed")
        except:
          print("Warning! Data Duplicacy Ocuur Or Mongo disonnection Lossed or Validation Failure ") 
        #collection.update_many({},{"$set" : {"Scrapy":"Not Scraped"}}, upsert=False )
        #client.close()


class dynamo:
      def dynamo_insert(self,path): 
        
        try:    
            client=pymongo.MongoClient("mongodb+srv://user:user@cluster0.l9qmd.mongodb.net/qpe?retryWrites=true&w=majority")
        except:
            print("error ocurr in connecting Atlas") 
            return 0
        try:
            db=client['qpe']
        except:
            print("error occur in fetching database") 
            return 0        
        try:
         
            if "dynamo" in db.list_collection_names():
                 collection=db['dynamo']
            else:
                    db.create_collection('dynamo', validator={
                        '$jsonSchema': {
                            'bsonType': 'object',
                            'additionalProperties': True,
                            'required': ["Internal ID"],
                        'properties': {
                                     'Internal ID': {
                                    'bsonType': 'string',
                                    'description': 'Set to default value',
                                    
                                }
                                
                                     

                        }
                        }
                        })
                    db['dynamo'].create_index(
                       [("Internal ID", pymongo.ASCENDING)],
                         unique=True
                        )   
                    
                            
                    collection=db['dynamo']    

        except:
            print("error occur in fetching collection")
            return 0
        requesting = []
        try:
         with open(path,encoding='utf-8') as f:
                myDict = json.load(f)
                #print(myDict)
                #requesting.append(InsertOne(myDict))
        except: 
           print("json file error")
           return 0 
       
        #print(myDict) 
        try:        
          result = collection.insert_many(myDict,ordered=False)
          print("Insertion Completed")
        except:
          print("Warning! Data Duplicacy Ocuur Or Mongo disonnection Lossed or Validation Failure ")
        #collection.update_many({},{"$set" : {"Scrapy":"Not Scraped"}}, upsert=False)    
        #client.close()

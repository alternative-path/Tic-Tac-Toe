from multiprocessing import context
import re
from unicodedata import category
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User,auth
from django.contrib import messages
import pandas as pd
import pymongo
from pymongo import MongoClient
def home(request):
        try:    
            client=pymongo.MongoClient("mongodb+srv://user:user@cluster0.l9qmd.mongodb.net/qpe?retryWrites=true&w=majority")
        except:
            print("error ocurr in connecting Atlas") 
            
        try:
            db=client['qpe']
        except:
            print("error occur in fetching database")
        collection=db['test']

        #search=input("Enter")

        results=collection.aggregate([   
                              {
    '$search': {
      'index': 'a',
      'queryString': {
        'query': '(Dhruv AND friendly) OR paws policy',
        'defaultPath':"content"
      },
      'highlight':{
          'path':"content"

      }
    }
                              }
      ,
{
    "$project":{
        "Company name":1,
        "content":1,
        "highlights":{

            "$meta":"searchHighlights"
        }
    }  
}

   

      ])
        result=list(results)

    
          

        return render(request,'index.html')
  
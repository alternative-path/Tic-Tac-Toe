import csv
import json
import pandas as pd
import pymongo
from pymongo import MongoClient, InsertOne,UpdateMany,UpdateOne


class scrap:
   def scrap_comnbine(self,dump_loc,scrap,scrap_out):
            try:
              df=pd.read_json(dump_loc)
            except:
              print("File fame(dump) not Found or File Error")

            try:
              ds=pd.read_json(scrap)
            except:
              print("File Scraper not Found or File Error")
            
            df=pd.DataFrame(df)   
            ds=pd.DataFrame(ds)
            row = len(df.axes[0])
            rows = len(ds.axes[0])  # computing number of rows and columns
            #cols = len(df.axes[1])
            data=[]
            df.sort_values(by=['id'])
            ds.sort_values(by=['idx'])
            for x in range(0,rows):
                index=ds.loc[x,'idx']
                for y in range(0,row):   
                      if index==df.loc[y,'id']:
                              data.append([df.loc[y,'company_name'].upper(),df.loc[y,'last_scraped_on'],
                              df.loc[y,'home_status'],df.loc[y,'aboutus_status'],
                              df.loc[y,'dynamo'],df.loc[y,'internal_id'],
                              ds.loc[x,'url'],ds.loc[x,'title'],
                              ds.loc[x,'content'],ds.loc[x,'icon']                          
                              ])
                              break
                      else:
                        continue 
            data=pd.DataFrame(data,columns=['Company name','Last_scraped_on',
                                            'Home_status','Aboutus_status','Dynamo',
                                              'Dynamo_internal_id','Scrapped_url','Title','content','icon'
                                              ])
            print("hello")
            try:  
                data.to_csv(scrap_out,mode='a',index=False,na_rep='Unknown') 

            except:
                print("Error in write Clean Csv file")
                return 0
            print("scrap cleaning done")




   def scrap_insert(self,path):
        try:    
            client=pymongo.MongoClient("mongodb+srv://user:user@cluster0.l9qmd.mongodb.net/qpe?retryWrites=true&w=majority")
        except:
            print("error ocurr in connecting Atlas") 
        try:
            db=client['qpe']
        except:
            print("error occur in fetching database") 
        
        try:
          df=pd.read_csv(path, encoding= 'unicode_escape')
        except:
          print("File not Found or File Error")

        rows = len(df.axes[0])  # computing number of rows and columns
        #cols = len(df.axes[1])
        new_field=[]
        fame_requests=[]
        dynamo_requests=[]
        for x in range(0,rows):

                if df.loc[x,'Dynamo']=="No":
                    
                  fame_requests.append(
                      UpdateMany({'Company name':df.loc[x,'Company name']},
                      {"$set":{"Last_scraped_on":df.loc[x,'Last_scraped_on'],
                      "Home_status":df.loc[x,'Home_status'],
                      "Aboutus_status":df.loc[x,'Aboutus_status'],
                      "Scrapped_url":df.loc[x,'Scrapped_url'],
                      "Title":df.loc[x,'Title'],
                      "content":df.loc[x,'content'],
                      "icon":df.loc[x,'icon'],
                      } },upsert=False
                      )
                   )
                if df.loc[x,'Dynamo']=="Yes": 
                    dynamo_requests.append(
                      UpdateOne({'Internal ID':df.loc[x,'Dynamo_internal_id']},
                      {"$set":{"Last_scraped_on":df.loc[x,'Last_scraped_on'],
                      "Home_status":df.loc[x,'Home_status'],
                      "Aboutus_status":df.loc[x,'Aboutus_status'],
                      "Scrapped_url":df.loc[x,'Scrapped_url'],
                      "Title":df.loc[x,'Title'],
                      "content":df.loc[x,'content'],
                      "icon":df.loc[x,'icon'],
                      }},upsert=False
                      )
                   )    
        db['fame'].bulk_write(fame_requests)
        print("Fame scraper data updated")
        db['dynamo'].bulk_write(dynamo_requests)
        print("Dynamo scraper data updated")      

from ast import Mult
import collections
from http.client import HTTPResponse
from sys import getsizeof
from typing import OrderedDict
import pymongo
import json
import pandas as pd
from pymongo import MongoClient, InsertOne,aggregation
if __name__=="__main__": 
        
        try:    
            client=pymongo.MongoClient("mongodb+srv://user:user@cluster0.l9qmd.mongodb.net/qpe?retryWrites=true&w=majority")
        except:
            print("error ocurr in connecting Atlas") 
            
        try:
            db=client['qpe']
        except:
            print("error occur in fetching database")
        collection=db['test']

        #search=input("Enter")

        results=collection.aggregate([   
                              {
    '$search': {
      'index': 'a',
      'queryString': {
        'query': '(Dhruv AND friendly) OR paws policy',
        'defaultPath':"content"
      },
      'highlight':{
          'path':"content"

      }
    }
                              }
      ,
      {"$limit":2},
{
    "$project":{
        "Company name":1,
        "content":1,
        "highlights":{

            "$meta":"searchHighlights"
        }
    }  
}

   

      ])
        result=list(results)
        print(result[0]['content'])
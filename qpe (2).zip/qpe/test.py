from ast import Mult
from gc import collect
from typing import OrderedDict
import pymongo
import json,bson
from pymongo import MongoClient, InsertOne
import csv

try:    
    client=pymongo.MongoClient("mongodb+srv://user:user@cluster0.l9qmd.mongodb.net/qpe?retryWrites=true&w=majority")
except:
    print("error ocurr in connecting Atlas") 
try:
    db=client['qpe']
except:
    print("error occur in fetching database") 

collection=db['test']


data = []
csvFilePath=r"C:\Users\Anil\Downloads\qpefiles\scrapy\scrap_combine.csv"     
jsonFilePath=r"C:\Users\Anil\Downloads\qpefiles\scrapy\scrap_combine.json"     
csv.field_size_limit(1000000000)
# Open a csv reader called DictReader
with open(csvFilePath, encoding='utf-8') as csvf:
    csvReader = csv.DictReader(csvf)

    
    # Convert each row into a dictionary
    # and add it to data

    for rows in csvReader:
      data.append(rows)

# Open a json writer, and use the json.dumps()
# function to dump data
try:

    with open(jsonFilePath, 'w') as jsonf:
       jsonf.write(json.dumps(data, indent=4))
       print("Dynamo Json Created Succesfully")

except:
    print("Error in write Clean json file")


with open(jsonFilePath,encoding='utf-8') as f:
                myDict = json.load(f)

  
result = collection.insert_many(myDict,ordered=False)
print("Insertion Completed")

print("Warning! Data Duplicacy Ocuur Or Mongo disonnection Lossed or Validation Failure ")

          